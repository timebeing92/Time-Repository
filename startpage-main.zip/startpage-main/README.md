# startpage
Is my custom start page for my browser. There are 3 themes that you can switch between

<img src="./assets/screengreen" />

<img src="./assets/screenblue" />

<img src="./assets/screengruvbox" />
